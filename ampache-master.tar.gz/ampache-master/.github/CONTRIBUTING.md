# Contribution

Please read [Development section](https://github.com/ampache/ampache/wiki#development).

## Bug report

Be sure the bug is not already fixed in `develop` branch or already reported in current open issues.
Please add [some logs](https://github.com/ampache/ampache/wiki/Troubleshooting#enable-logging) with your new issue.
